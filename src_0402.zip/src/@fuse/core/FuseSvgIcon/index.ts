export { default } from './FuseSvgIcon';
