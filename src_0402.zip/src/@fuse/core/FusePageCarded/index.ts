export { default } from './FusePageCarded';
