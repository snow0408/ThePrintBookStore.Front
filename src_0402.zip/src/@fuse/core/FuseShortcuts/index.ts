export { default } from './FuseShortcuts';
