/**
 * Represents a FuseNavBadge.
 */
export type FuseNavBadgeType = {
	bg?: string;
	fg?: string;
	title: string;
	classes?: string;
};
