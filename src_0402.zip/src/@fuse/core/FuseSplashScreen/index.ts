export { default } from './FuseSplashScreen';
