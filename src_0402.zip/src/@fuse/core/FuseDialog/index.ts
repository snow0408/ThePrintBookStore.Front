export { default } from './FuseDialog';
