﻿import { Outlet } from 'react-router-dom';

/**
 * The Discount app.
 */
function DiscountApp() {
	return <Outlet />;
}

export default DiscountApp;
